﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
namespace VehicleApiService.Models
{
    public class Vehicle
    {
        public int VehicleId { get; set; }

        [Required]
        [MaxLength(50)]
        [Column(TypeName = "varchar")]
        public string CustomerName { get; set; }
        
        [Required]//Age 
        [Column(TypeName = "datetime")]
        public DateTime CustomerDOB { get; set; }

        [Required]
        [MaxLength(200)]
        [Column(TypeName = "varchar")]
        public string CustomerAddress { get; set; }

        [Required]
        [MaxLength(200)]
        [Column(TypeName = "varchar")]
        public string Vehicletype { get; set; }
        [Required]
        [Column(TypeName = "varchar")]
        [MaxLength(15)]
        public string CustomerContactNo { get; set; }
        [MaxLength(50)]
        [Column(TypeName = "varchar")]
        [Required]
        public string VehicleCategory { get; set; }
        [Required]
        [MaxLength(50)]
        [Column(TypeName = "varchar")]
        public string MakerName { get; set; }
        [Required]
        [Column(TypeName = "datetime")]
        public DateTime ManufactoringDate { get; set; }
        [Required]
        [Column(TypeName = "int")]
        public int NumberofCylinder { get; set; }
        [Required]
        [Column(TypeName = "int")]
        public int Power { get; set; }
        [Required]
        [Column(TypeName = "int")]
        public int CubicCapacity { get; set; }
        [MaxLength(50)]
        [Column(TypeName = "varchar")]
        [Required]
        public string Model { get; set; }
        [Required]
        [MaxLength(50)]
        [Column(TypeName = "varchar")]
        public string WheelBase { get; set; }
        [Required]
        [MaxLength(50)]
        [Column(TypeName = "varchar")]
        public string ChesisNumber { get; set; }
        [Required]
        [Column(TypeName = "int")]
        public int SeatingCapacity { get; set; }
        [Required]
        [MaxLength(50)]
        [Column(TypeName = "varchar")]
        public string FuelType { get; set; }
        [Required]
        [Column(TypeName = "int")]
        public int UnladenWeight { get; set; }
        [Required]
        [MaxLength(50)]
        [Column(TypeName = "varchar")]
        public string Color { get; set; }
        [Required]
        [Column(TypeName = "int")]
        public int TyreSize { get; set; }
        [Required]
        [Column(TypeName = "int")]
        public int GrossWeight { get; set; }
         

    }
}