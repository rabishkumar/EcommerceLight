﻿using VehicleApiService.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Cors;

namespace VehicleApiService
{
    
   // [EnableCors(origins: "*", headers: "*", methods: "*")] // tune to your needs
    [RoutePrefix("")]
    public class VehicleServiceController : ApiController
    {
        
        DataContext context = new DataContext();

        [HttpPost]
        public int AddVehicle(Vehicle vehicle)
        {
           
            context.Vehicle.Add(vehicle);
            context.SaveChanges();
            return vehicle.VehicleId;
        }

        [HttpGet]
        public Vehicle GetVehicle(int vehicleId)
        {
            Vehicle vehicle = context.Vehicle.Find(vehicleId);
            return vehicle;
        }

        [HttpGet]
        public List<Vehicle> GetVehiclesList()
        {
            return context.Vehicle.ToList();
        }

        [HttpPut]
        public void ModifyVehicle(Vehicle vehicle, int vehicleId)
        {
            if (vehicle.VehicleId == vehicleId)
            {
                context.Entry(vehicle).State = EntityState.Modified;
                context.SaveChanges();
            }
        }

        [HttpDelete]
        public void DeleteVehicle(int vehicleid)
        {
            Vehicle vehicle = context.Vehicle.Find(vehicleid);
            if (vehicle != null)
            {
                context.Vehicle.Remove(vehicle);
                context.SaveChanges();
            }

        }
    }
}
